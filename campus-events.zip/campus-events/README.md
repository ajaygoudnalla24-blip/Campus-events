# db.json

json-server --watch db.json --port 3001

# react

npm install

npm start