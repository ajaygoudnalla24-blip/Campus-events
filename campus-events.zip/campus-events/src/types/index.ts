export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  datetime: string;
  location: string;
  capacity: number;
  seatsRemaining: number;
  tags: string[];
}

export interface Rsvp {
  id: string;
  eventId: string;
  userId: string;
  status: 'yes' | 'no' | 'waitlist';
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface UiState {
  theme: 'light' | 'dark';
}