import { useQuery } from '@tanstack/react-query';
import { eventsApi } from '../services/api';
import { Event } from '../types';

export const useEvent = (id: string | undefined) => {
  return useQuery<Event, Error>({
    queryKey: ['event', id],
    queryFn: () => {
      if (!id) throw new Error('Event ID is required');
      return eventsApi.getEvent(id);
    },
    enabled: !!id,
  });
};