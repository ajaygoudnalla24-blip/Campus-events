import { useQuery } from '@tanstack/react-query';
import { eventsApi } from '../services/api';
import { Event } from '../types';

export const useEvents = () => {
  return useQuery<Event[], Error>({
    queryKey: ['events'],
    queryFn: eventsApi.getEvents,
  });
};