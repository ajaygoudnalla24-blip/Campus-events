import { useMutation, useQueryClient } from '@tanstack/react-query';
import { rsvpsApi } from '../services/api';
import { Rsvp } from '../types';

export const useRsvpMutation = (userId: string) => {
  const queryClient = useQueryClient();

  return useMutation<Rsvp, Error, { eventId: string; status: Rsvp['status'] }>({
    mutationFn: async ({ eventId, status }: { eventId: string; status: Rsvp['status'] }) => {
      const existingRsvp = await rsvpsApi.getExistingRsvp(eventId, userId);
      
      if (existingRsvp) {
        return rsvpsApi.updateRsvp(existingRsvp.id, status, existingRsvp.status);
      } else {
        return rsvpsApi.createRsvp({ eventId, userId, status });
      }
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      queryClient.invalidateQueries({ queryKey: ['event', variables.eventId] });
      queryClient.invalidateQueries({ queryKey: ['userRsvps', userId] });
    },
  });
};