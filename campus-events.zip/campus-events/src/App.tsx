import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Home from './pages/Home';
import EventDetails from './pages/EventDetails';
import SignIn from './pages/SignIn';
import MyResponses from './pages/MyResponses';
import NotFound from './pages/NotFound';
import CreateEvent from './pages/CreateEvent';
import ProtectedRoute from './components/ProtectedRoute';
import { RootState } from './store';
import './App.css';

const App: React.FC = () => {
  const { user } = useSelector((state: RootState) => state.auth);

  return (
    <Router>
      <div className="App">
        <nav style={{ padding: '1rem', borderBottom: '1px solid #ccc', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <Link to="/" style={{ marginRight: '1rem' }}>Home</Link>
            <Link to="/me/rsvps" style={{ marginRight: '1rem' }}>My Responses</Link>
            <Link to="/create-event" style={{ marginRight: '1rem' }}>Create Event</Link>
          </div>
          <div>
            {user ? (
              <span>Welcome, {user.name}!</span>
            ) : (
              <Link to="/signin">Sign In</Link>
            )}
          </div>
        </nav>

        <main style={{ padding: '1rem' }}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/events/:id" element={<EventDetails />} />
            <Route path="/signin" element={<SignIn />} />
            <Route path="/create-event" element={<CreateEvent />} />
            <Route 
              path="/me/rsvps" 
              element={
                <ProtectedRoute>
                  <MyResponses />
                </ProtectedRoute>
              } 
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;