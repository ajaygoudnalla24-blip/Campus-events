import { WebStorage } from 'redux-persist';

const persistConfig = {
  key: 'root',
  storage: typeof window !== 'undefined' ? require('redux-persist/lib/storage').default : null,
  whitelist: ['auth'],
};

export default persistConfig;