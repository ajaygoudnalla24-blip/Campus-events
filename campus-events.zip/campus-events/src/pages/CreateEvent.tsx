import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { eventsApi } from '../services/api';
import { useNavigate, Link } from 'react-router-dom';
import { Event } from '../types';

const eventSchema = yup.object({
  title: yup.string().required('Title is required').min(5, 'Title must be at least 5 characters'),
  description: yup.string().required('Description is required').min(10, 'Description must be at least 10 characters'),
  datetime: yup.string().required('Date and time are required'),
  location: yup.string().required('Location is required'),
  capacity: yup.number().required('Capacity is required').min(1, 'Capacity must be at least 1'),
  tags: yup.string().optional(),
}).required();

type EventFormData = {
  title: string;
  description: string;
  datetime: string;
  location: string;
  capacity: number;
  tags?: string;
};

const CreateEvent: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<EventFormData>({
    resolver: yupResolver(eventSchema) as any, 
    defaultValues: {
      tags: '',
    }
  });

  const createEventMutation = useMutation({
    mutationFn: eventsApi.createEvent,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      navigate('/');
    },
  });

  const onSubmit = (data: EventFormData) => {
    const eventData: Omit<Event, 'id'> = {
      title: data.title,
      description: data.description,
      datetime: data.datetime,
      location: data.location,
      capacity: Number(data.capacity),
      seatsRemaining: Number(data.capacity),
      tags: data.tags ? data.tags.split(',').map(tag => tag.trim()).filter(tag => tag !== '') : [],
    };
    
    createEventMutation.mutate(eventData);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <h1>Create New Event</h1>
      
      {createEventMutation.isError && (
        <div style={{ 
          padding: '0.75rem', 
          backgroundColor: '#ffebee', 
          color: '#c62828', 
          marginBottom: '1rem',
          borderRadius: '4px'
        }}>
          Error creating event: {(createEventMutation.error as Error)?.message}
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        <div>
          <label htmlFor="title" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Event Title *
          </label>
          <input
            id="title"
            type="text"
            {...register('title')}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: errors.title ? '2px solid #f44336' : '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem'
            }}
            placeholder="Enter event title"
          />
          {errors.title && (
            <p style={{ color: '#f44336', margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>
              {errors.title.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="description" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Description *
          </label>
          <textarea
            id="description"
            rows={4}
            {...register('description')}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: errors.description ? '2px solid #f44336' : '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem',
              resize: 'vertical'
            }}
            placeholder="Enter event description"
          />
          {errors.description && (
            <p style={{ color: '#f44336', margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>
              {errors.description.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="datetime" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Date & Time *
          </label>
          <input
            id="datetime"
            type="datetime-local"
            {...register('datetime')}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: errors.datetime ? '2px solid #f44336' : '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem'
            }}
          />
          {errors.datetime && (
            <p style={{ color: '#f44336', margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>
              {errors.datetime.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="location" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Location *
          </label>
          <input
            id="location"
            type="text"
            {...register('location')}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: errors.location ? '2px solid #f44336' : '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem'
            }}
            placeholder="Enter event location"
          />
          {errors.location && (
            <p style={{ color: '#f44336', margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>
              {errors.location.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="capacity" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Capacity *
          </label>
          <input
            id="capacity"
            type="number"
            min="1"
            {...register('capacity', { valueAsNumber: true })}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: errors.capacity ? '2px solid #f44336' : '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem'
            }}
            placeholder="Enter maximum capacity"
          />
          {errors.capacity && (
            <p style={{ color: '#f44336', margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>
              {errors.capacity.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="tags" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Tags (comma-separated)
          </label>
          <input
            id="tags"
            type="text"
            {...register('tags')}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem'
            }}
            placeholder="e.g., AI, ethics, workshop"
          />
          <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.8rem', color: '#666' }}>
            Separate multiple tags with commas
          </p>
        </div>

        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
          <button 
            type="submit" 
            disabled={isSubmitting || createEventMutation.isPending}
            style={{
              padding: '0.75rem 2rem',
              backgroundColor: '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: (isSubmitting || createEventMutation.isPending) ? 'not-allowed' : 'pointer',
              opacity: (isSubmitting || createEventMutation.isPending) ? 0.6 : 1,
              fontSize: '1rem',
              flex: 1
            }}
          >
            {createEventMutation.isPending ? 'Creating Event...' : 'Create Event'}
          </button>
          
          <Link 
            to="/"
            style={{
              padding: '0.75rem 2rem',
              backgroundColor: '#6c757d',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              textDecoration: 'none',
              textAlign: 'center',
              flex: 1
            }}
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
};

export default CreateEvent;