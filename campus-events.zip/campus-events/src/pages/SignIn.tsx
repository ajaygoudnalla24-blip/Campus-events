import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useDispatch } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import { signIn } from '../store/slices/authSlice';
import { User } from '../types';

const signInSchema = yup.object({
  name: yup
    .string()
    .required('Name is required')
    .min(2, 'Name must be at least 2 characters')
    .matches(/^[a-zA-Z\s]*$/, 'Name can only contain letters and spaces'),
  email: yup
    .string()
    .required('Email is required')
    .email('Please enter a valid email address')
    .matches(/\.edu$/, 'Please use a .edu email address'),
}).required();

type SignInFormData = yup.InferType<typeof signInSchema>;

const SignIn: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const { 
    register, 
    handleSubmit, 
    formState: { errors, isSubmitting, isValid, touchedFields } 
  } = useForm<SignInFormData>({
    resolver: yupResolver(signInSchema),
    mode: 'onChange', 
  });

  const onSubmit = (data: SignInFormData) => {
    const user: User = {
      id: `user-${Date.now()}`,
      name: data.name.trim(),
      email: data.email.toLowerCase().trim(),
    };
    
    dispatch(signIn(user));
    navigate('/');
  };

  return (
    <div style={{ maxWidth: '400px', margin: '0 auto' }}>
      <h1>Sign In</h1>
      <p style={{ color: '#666', marginBottom: '2rem' }}>
        Enter your details to sign in (this is a fake login)
      </p>
      
      <form onSubmit={handleSubmit(onSubmit)} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        <div>
          <label htmlFor="name" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Full Name *
          </label>
          <input
            id="name"
            type="text"
            {...register('name')}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: errors.name ? '2px solid #f44336' : 
                     touchedFields.name ? '2px solid #4CAF50' : '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem',
              transition: 'border-color 0.3s'
            }}
            placeholder="Enter your full name"
          />
          {errors.name && (
            <p style={{ color: '#f44336', margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>
              {errors.name.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="email" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Email *
          </label>
          <input
            id="email"
            type="email"
            {...register('email')}
            style={{ 
              width: '100%', 
              padding: '0.75rem', 
              border: errors.email ? '2px solid #f44336' : 
                     touchedFields.email ? '2px solid #4CAF50' : '1px solid #ccc',
              borderRadius: '4px',
              fontSize: '1rem',
              transition: 'border-color 0.3s'
            }}
            placeholder="Enter your .edu email"
          />
          {errors.email && (
            <p style={{ color: '#f44336', margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>
              {errors.email.message}
            </p>
          )}
        </div>

        <button 
          type="submit" 
          disabled={isSubmitting || !isValid}
          style={{
            padding: '0.75rem',
            backgroundColor: (isSubmitting || !isValid) ? '#cccccc' : '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: (isSubmitting || !isValid) ? 'not-allowed' : 'pointer',
            fontSize: '1rem',
            fontWeight: 'bold',
            transition: 'background-color 0.3s'
          }}
        >
          {isSubmitting ? 'Signing In...' : 'Sign In'}
        </button>

        <div style={{ 
          padding: '1rem', 
          backgroundColor: '#f8f9fa', 
          borderRadius: '4px',
          border: '1px solid #e9ecef'
        }}>
          <p style={{ margin: 0, fontSize: '0.9rem', color: '#666' }}>
            <strong>Demo:</strong> Any name + email ending with .edu
          </p>
        </div>
      </form>

      <p style={{ marginTop: '2rem', textAlign: 'center' }}>
        <Link to="/" style={{ color: '#007bff', textDecoration: 'none' }}>
          ← Back to Events
        </Link>
      </p>
    </div>
  );
};

export default SignIn;