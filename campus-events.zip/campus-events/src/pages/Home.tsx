import React, { useState, useMemo } from 'react';
import { useEvents } from '../hooks/useEvents';
import { Event } from '../types';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const { data: allEvents, isPending, error, isFetching } = useEvents();

  const filteredEvents = useMemo(() => {
    if (!allEvents) return [];
    
    if (!searchTerm.trim()) return allEvents;
    
    return allEvents.filter(event => 
      event.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [allEvents, searchTerm]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };

  const handleClearSearch = () => {
    setSearchTerm('');
  };

  if (isPending) return (
    <div style={{ 
      textAlign: 'center', 
      padding: '3rem',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '1rem'
    }}>
      <div style={{
        width: '40px',
        height: '40px',
        border: '4px solid #f3f3f3',
        borderTop: '4px solid #007bff',
        borderRadius: '50%',
        animation: 'spin 1s linear infinite'
      }}></div>
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
      <div style={{ fontSize: '1.1rem', color: '#666' }}>Loading events...</div>
    </div>
  );
  
  if (error) return (
    <div style={{ 
      color: 'red', 
      textAlign: 'center', 
      padding: '2rem',
      backgroundColor: '#ffebee',
      border: '1px solid #f44336',
      borderRadius: '4px',
      margin: '1rem'
    }}>
      <h3>Error Loading Events</h3>
      <p>{error.message}</p>
      <button 
        onClick={() => window.location.reload()}
        style={{
          padding: '0.5rem 1rem',
          backgroundColor: '#f44336',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer',
          marginTop: '1rem'
        }}
      >
        Try Again
      </button>
    </div>
  );

  return (
    <div>
      <h1>Upcoming Events</h1>
      
      <div style={{ marginBottom: '2rem' }}>
        <form onSubmit={handleSearch} style={{ marginBottom: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
            <input
              type="text"
              placeholder="Search events by title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                padding: '0.75rem',
                width: '300px',
                border: '1px solid #ccc',
                borderRadius: '4px',
                fontSize: '1rem'
              }}
            />
            <button 
              type="submit"
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: '#007bff',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontWeight: '500'
              }}
            >
              Search
            </button>
            {searchTerm && (
              <button 
                type="button"
                onClick={handleClearSearch}
                style={{
                  padding: '0.75rem 1rem',
                  backgroundColor: '#6c757d',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Clear
              </button>
            )}
          </div>
        </form>

        {searchTerm && (
          <div style={{ 
            padding: '0.5rem', 
            backgroundColor: '#e7f3ff', 
            borderRadius: '4px',
            border: '1px solid #b3d9ff'
          }}>
            <p style={{ margin: 0, fontSize: '0.9rem', color: '#0066cc' }}>
              <strong>Searching for:</strong> "{searchTerm}"
              <span style={{ marginLeft: '1rem' }}>
                <strong>Found:</strong> {filteredEvents.length} event{filteredEvents.length !== 1 ? 's' : ''}
              </span>
            </p>
          </div>
        )}
      </div>

      {isFetching && (
        <div style={{ 
          padding: '0.75rem', 
          backgroundColor: '#e3f2fd', 
          marginBottom: '1rem',
          borderRadius: '4px',
          border: '1px solid #2196f3',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem'
        }}>
          <div style={{
            width: '16px',
            height: '16px',
            border: '2px solid #f3f3f3',
            borderTop: '2px solid #2196f3',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }}></div>
          <span style={{ color: '#1976d2', fontWeight: '500' }}>
            Refreshing events...
          </span>
        </div>
      )}
      
      {filteredEvents.length === 0 ? (
        <div style={{ 
          textAlign: 'center', 
          padding: '3rem', 
          border: '1px solid #ccc', 
          borderRadius: '4px', 
          backgroundColor: '#f8f9fa' 
        }}>
          <h3 style={{ color: '#666', marginBottom: '1rem' }}>
            {searchTerm ? 'No Events Found' : 'No Upcoming Events'}
          </h3>
          <p style={{ color: '#666', marginBottom: '1.5rem' }}>
            {searchTerm 
              ? `No events found matching "${searchTerm}"`
              : 'There are no upcoming events at the moment.'
            }
          </p>
          {searchTerm && (
            <button 
              onClick={handleClearSearch}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: '#007bff',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '1rem',
                fontWeight: '500'
              }}
            >
              Show All Events
            </button>
          )}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {filteredEvents.map((event) => (
            <div key={event.id} style={{ 
              border: '1px solid #ccc', 
              padding: '1.5rem', 
              borderRadius: '8px', 
              backgroundColor: 'white',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <h3 style={{ margin: '0 0 1rem 0', fontSize: '1.25rem' }}>
                <Link to={`/events/${event.id}`} style={{ color: '#007bff', textDecoration: 'none' }}>
                  {event.title}
                </Link>
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.5rem' }}>
                <p><strong>Date:</strong> {new Date(event.datetime).toLocaleDateString()}</p>
                <p><strong>Time:</strong> {new Date(event.datetime).toLocaleTimeString()}</p>
                <p><strong>Location:</strong> {event.location}</p>
                <p>
                  <strong>Seats:</strong> 
                  <span style={{ 
                    color: event.seatsRemaining === 0 ? 'red' : 
                           event.seatsRemaining < 10 ? 'orange' : 'green',
                    fontWeight: 'bold',
                    marginLeft: '0.5rem'
                  }}>
                    {event.seatsRemaining} / {event.capacity} available
                  </span>
                </p>
              </div>
              <p><strong>Tags:</strong> {event.tags.join(', ')}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;