import React from 'react';
import { useSelector } from 'react-redux';
import { useQuery } from '@tanstack/react-query';
import { rsvpsApi, eventsApi } from '../services/api';
import { RootState } from '../store';
import { Link } from 'react-router-dom';
import { Rsvp, Event } from '../types';

const MyResponses: React.FC = () => {
  const { user } = useSelector((state: RootState) => state.auth);

  const { data: rsvps, isPending: rsvpsPending, error: rsvpsError } = useQuery<Rsvp[], Error>({
    queryKey: ['userRsvps', user?.id],
    queryFn: () => rsvpsApi.getRsvpsByUser(user?.id || ''),
    enabled: !!user?.id,
  });

  const { data: events, isPending: eventsPending } = useQuery<Event[], Error>({
    queryKey: ['events'],
    queryFn: () => eventsApi.getEvents(),
    enabled: !!rsvps && rsvps.length > 0,
  });

  const getEventDetails = (eventId: string) => {
    return events?.find((event: Event) => event.id === eventId);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'yes': return '#4CAF50';
      case 'no': return '#f44336';
      case 'waitlist': return '#FF9800';
      default: return '#666';
    }
  };

  if (rsvpsPending) return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <div>Loading your responses...</div>
    </div>
  );
  
  if (rsvpsError) return (
    <div style={{ color: 'red', textAlign: 'center', padding: '2rem' }}>
      Error loading responses: {rsvpsError.message}
    </div>
  );

  return (
    <div>
      <h1>My Responses</h1>
      <p>Welcome, {user?.name}! Here are your event responses:</p>
      
      {!rsvps || rsvps.length === 0 ? (
        <div style={{ 
          marginTop: '2rem', 
          padding: '3rem', 
          border: '1px solid #ccc', 
          borderRadius: '8px', 
          textAlign: 'center',
          backgroundColor: '#f8f9fa'
        }}>
          <h3>No RSVPs Yet</h3>
          <p>You haven't RSVP'd to any events yet.</p>
          <p>
            <Link to="/" style={{ 
              color: '#007bff', 
              textDecoration: 'none',
              fontWeight: 'bold',
              fontSize: '1.1rem'
            }}>
              Browse events →
            </Link> and RSVP to see your responses here.
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '2rem' }}>
          {eventsPending && (
            <div style={{ 
              padding: '0.5rem', 
              backgroundColor: '#e3f2fd', 
              borderRadius: '4px',
              textAlign: 'center'
            }}>
              Loading event details...
            </div>
          )}
          
          {rsvps.map((rsvp: Rsvp) => {
            const event = getEventDetails(rsvp.eventId);
            return (
              <div key={rsvp.id} style={{ 
                border: '1px solid #ccc', 
                padding: '1.5rem', 
                borderRadius: '8px',
                backgroundColor: 'white'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ flex: 1 }}>
                    <h3 style={{ margin: '0 0 0.5rem 0' }}>
                      {event ? event.title : `Event ${rsvp.eventId}`}
                    </h3>
                    {event && (
                      <>
                        <p style={{ margin: '0.25rem 0', color: '#666' }}>
                          <strong>Date:</strong> {new Date(event.datetime).toLocaleDateString()}
                        </p>
                        <p style={{ margin: '0.25rem 0', color: '#666' }}>
                          <strong>Location:</strong> {event.location}
                        </p>
                      </>
                    )}
                    <p style={{ margin: '0.5rem 0 0 0' }}>
                      <strong>Your Response:</strong> 
                      <span style={{
                        color: getStatusColor(rsvp.status),
                        fontWeight: 'bold',
                        marginLeft: '0.5rem',
                        padding: '0.25rem 0.75rem',
                        backgroundColor: `${getStatusColor(rsvp.status)}20`,
                        borderRadius: '20px',
                        fontSize: '0.9rem'
                      }}>
                        {rsvp.status.toUpperCase()}
                      </span>
                    </p>
                  </div>
                  {event && (
                    <Link 
                      to={`/events/${rsvp.eventId}`} 
                      style={{ 
                        padding: '0.5rem 1rem', 
                        backgroundColor: '#007bff', 
                        color: 'white', 
                        textDecoration: 'none', 
                        borderRadius: '4px',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      View Event
                    </Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MyResponses;