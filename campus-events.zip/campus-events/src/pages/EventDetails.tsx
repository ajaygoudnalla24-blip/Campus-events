import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useEvent } from '../hooks/useEvent';
import { useRsvpMutation } from '../hooks/useRsvpMutation';
import { RootState } from '../store';
import { Rsvp } from '../types';

const EventDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useSelector((state: RootState) => state.auth);
  
  const { data: event, isPending, error } = useEvent(id);
  const rsvpMutation = useRsvpMutation(user?.id || '');

  const handleRsvp = (status: Rsvp['status']) => {
    if (!isAuthenticated || !user) {
      navigate('/signin');
      return;
    }

    if (!event) return;

    rsvpMutation.mutate({
      eventId: event.id,
      status,
    });
  };

  if (isPending) return <div>Loading event details...</div>;
  if (error) return <div>Error loading event: {error.message}</div>;
  if (!event) return <div>Event not found</div>;

  const isEventFull = event.seatsRemaining === 0;

  return (
    <div>
      <Link to="/" style={{ marginBottom: '1rem', display: 'block' }}>← Back to Events</Link>
      
      <div style={{ border: '1px solid #ccc', padding: '2rem', borderRadius: '8px' }}>
        <h1>{event.title}</h1>
        <p><strong>Description:</strong> {event.description}</p>
        <p><strong>Date & Time:</strong> {new Date(event.datetime).toLocaleString()}</p>
        <p><strong>Location:</strong> {event.location}</p>
        <p><strong>Capacity:</strong> {event.seatsRemaining} / {event.capacity} seats available</p>
        <p><strong>Tags:</strong> {event.tags.join(', ')}</p>
        
        <div style={{ marginTop: '2rem' }}>
          <h3>RSVP for this event</h3>
          
          {rsvpMutation.isPending && (
            <div style={{ padding: '0.5rem', backgroundColor: '#e3f2fd', marginBottom: '1rem' }}>
              Submitting your RSVP...
            </div>
          )}

          {rsvpMutation.isError && (
            <div style={{ padding: '0.5rem', backgroundColor: '#ffebee', color: '#c62828', marginBottom: '1rem' }}>
              Error submitting RSVP: {rsvpMutation.error.message}
            </div>
          )}

          {rsvpMutation.isSuccess && (
            <div style={{ padding: '0.5rem', backgroundColor: '#e8f5e8', color: '#2e7d32', marginBottom: '1rem' }}>
              RSVP submitted successfully!
            </div>
          )}

          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', flexWrap: 'wrap' }}>
            <button 
              onClick={() => handleRsvp('yes')}
              disabled={rsvpMutation.isPending || (isEventFull && !user)}
              style={{ 
                padding: '0.75rem 1.5rem', 
                backgroundColor: isEventFull ? '#cccccc' : '#4CAF50', 
                color: 'white', 
                border: 'none', 
                borderRadius: '4px',
                cursor: (rsvpMutation.isPending || (isEventFull && !user)) ? 'not-allowed' : 'pointer'
              }}
              title={isEventFull ? "Event is full" : "Confirm attendance"}
            >
              {isEventFull ? "Event Full" : "Yes, I'm Coming"}
            </button>
            
            <button 
              onClick={() => handleRsvp('no')}
              disabled={rsvpMutation.isPending}
              style={{ 
                padding: '0.75rem 1.5rem', 
                backgroundColor: '#f44336', 
                color: 'white', 
                border: 'none', 
                borderRadius: '4px',
                cursor: rsvpMutation.isPending ? 'not-allowed' : 'pointer'
              }}
            >
              No, I Can't Make It
            </button>
            
            <button 
              onClick={() => handleRsvp('waitlist')}
              disabled={rsvpMutation.isPending}
              style={{ 
                padding: '0.75rem 1.5rem', 
                backgroundColor: '#FF9800', 
                color: 'white', 
                border: 'none', 
                borderRadius: '4px',
                cursor: rsvpMutation.isPending ? 'not-allowed' : 'pointer'
              }}
            >
              Waitlist
            </button>
          </div>
          
          {!isAuthenticated ? (
            <p style={{ marginTop: '1rem', fontSize: '0.9rem', color: '#666' }}>
              You need to be signed in to RSVP
            </p>
          ) : isEventFull ? (
            <p style={{ marginTop: '1rem', fontSize: '0.9rem', color: '#d32f2f' }}>
              This event is full. You can join the waitlist in case spots open up.
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default EventDetails;