import axios from 'axios';
import { Event, Rsvp } from '../types';

const API_BASE_URL = 'http://localhost:3001';

const api = axios.create({
  baseURL: API_BASE_URL,
});

export const eventsApi = {
  getEvents: async (): Promise<Event[]> => {
    const response = await api.get('/events');
    return response.data;
  },

  getEvent: async (id: string): Promise<Event> => {
    const response = await api.get(`/events/${id}`);
    return response.data;
  },

  createEvent: async (eventData: Omit<Event, 'id'>): Promise<Event> => {
    const response = await api.post('/events', eventData);
    return response.data;
  },

  updateEvent: async (id: string, eventData: Partial<Event>): Promise<Event> => {
    const response = await api.patch(`/events/${id}`, eventData);
    return response.data;
  },
};

export const rsvpsApi = {
  getRsvpsByUser: async (userId: string): Promise<Rsvp[]> => {
    const response = await api.get(`/rsvps?userId=${userId}`);
    return response.data;
  },

  getRsvpsByEvent: async (eventId: string): Promise<Rsvp[]> => {
    const response = await api.get(`/rsvps?eventId=${eventId}`);
    return response.data;
  },

  createRsvp: async (rsvpData: Omit<Rsvp, 'id'>): Promise<Rsvp> => {
    const response = await api.post('/rsvps', rsvpData);
    
    if (rsvpData.status === 'yes') {
      try {
        const event = await eventsApi.getEvent(rsvpData.eventId);
        if (event.seatsRemaining > 0) {
          await eventsApi.updateEvent(rsvpData.eventId, {
            seatsRemaining: event.seatsRemaining - 1
          });
        }
      } catch (error) {
        console.error('Failed to update event seats:', error);
      }
    }
    
    return response.data;
  },

  updateRsvp: async (rsvpId: string, status: Rsvp['status'], previousStatus?: Rsvp['status']): Promise<Rsvp> => {
    const response = await api.patch(`/rsvps/${rsvpId}`, { status });
    
    if (previousStatus) {
      try {
        const rsvp = await api.get(`/rsvps/${rsvpId}`).then(res => res.data);
        const event = await eventsApi.getEvent(rsvp.eventId);
        
        let newSeatsRemaining = event.seatsRemaining;
        
        if (previousStatus === 'yes' && status !== 'yes') {
          newSeatsRemaining = event.seatsRemaining + 1;
        }
        else if (previousStatus !== 'yes' && status === 'yes' && event.seatsRemaining > 0) {
          newSeatsRemaining = event.seatsRemaining - 1;
        }
        
        if (newSeatsRemaining !== event.seatsRemaining) {
          await eventsApi.updateEvent(rsvp.eventId, {
            seatsRemaining: newSeatsRemaining
          });
        }
      } catch (error) {
        console.error('Failed to update event seats during RSVP update:', error);
      }
    }
    
    return response.data;
  },

  getExistingRsvp: async (eventId: string, userId: string): Promise<Rsvp | null> => {
    const response = await api.get(`/rsvps?eventId=${eventId}&userId=${userId}`);
    return response.data[0] || null;
  },
};